

<?php $__env->startSection('container'); ?>
    <div class="container isi">
        <div class="div">
            <div class="row">
                <a href="/database" class="navbar-brand">
                    <h1>DATABASE</h1>
                </a>
            </div>
            <div class="row justify-content-between">
                <div class="col-md-3 mb-3">
                    <a href="" class="btn btn-primary rounded-pill">Tambah Data</a>
                </div>
                <div class="col-md-6 mb-3">
                    <form action="/database">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Cari..." name="search" value="<?php echo e(request('search')); ?>">
                            <button class="btn btn-outline-primary" type="submit">Cari</button>
                          </div>
                          
                    </form>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama Makam</th>
                        <th scope="col">Kapasitas</th>
                        <th scope="col">Booking Fee</th>
                        <th scope="col">Ukuran (P)</th>
                        <th scope="col">Ukuran (L)</th>
                        <th scope="col">Ukuran (T)</th>
                        <th scope="col">Harga Tunai</th>
                        <th scope="col">Harga Cicilan</th>
                        <th scope="col">Tindakan</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $listkavling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(++$key); ?></th>
                    <td><?php echo e($list->nama); ?></td>
                    <td><?php echo e($list->formatRupiah('booking')); ?>,-</td>
                    <td><?php echo e($list->panjang); ?>m</td>
                    <td><?php echo e($list->lebar); ?>m</td>
                    <td><?php echo e($list->panjang); ?>m</td>
                    <td><?php echo e($list->total); ?>m<sup>2</sup></td>
                    <td><?php echo e($list->formatRupiah('tunai')); ?>,-</td>
                    <td><?php echo e($list->formatRupiah('cicil')); ?>,-</td>
                    <td><div class="text-center">
                        <a href=""><i class="bi bi-pencil-square"></i></a>
                        <a href=""><i class="bi bi-trash"></i></a></td>
                    </div>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek Laravel\mmgarden\resources\views/database.blade.php ENDPATH**/ ?>
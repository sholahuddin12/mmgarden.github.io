

<?php $__env->startSection('container'); ?>
    


<div class="background">
  <div class="jumbotron2 d-flex align-items-center">
      <div class="grid container text-center ">
          <div class="d-beranda mx-auto ">
              <h1>List Kavling Pemakaman Islami</h1>
              <h1><b>MADINAH MEMORIAL GARDEN</b></h1>
          </div>
      </div>
  </div>
  <div class="list-kavling container text-center my-3">
    <h1>Berikut Skema Lahan Kavling Pemakaman Islami</h1>
    <h1><strong>Madinah Memorial Garden</strong></h1>
    <div class="row justify-content-evenly">
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/1.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/2.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/3.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/4.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/5.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/6.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/7.jpeg" class="img-thumbnail" alt="...">
      </div>
      <div class="col-12 col-lg-5 m-2">
        <img src="/img/8.jpeg" class="img-thumbnail" alt="...">
      </div>
    </div>
  </div>
</div>

<div class="container text-center my-3">
    <h3>Tersedia berbagai pilihan type kavling yang dapat disesuaikan dengan kebutuan pengguna mulai dari kavling perorangan, pasangan atau keluarga.</h3>
    <h3>Berikut pilihan kavling yang tersedia di <strong>MMGarden</strong> :</h3>
    <div class="container text-center">
        <div class="row justify-content-evenly me-0 me-lg-5">
            <br>
            <?php $__currentLoopData = $listkavling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="col-12 col-lg-4 p-3 ">
              <div class="card text-start">
                <div class="card-header">
                  <strong><?php echo e($list->nama); ?></strong>
                </div>
                <div class="card-body">
                  <p class="card-text">Kapasitas <?php echo e($list->kapasitas); ?></p>
                  
                  <p class="card-text">Ukuran <?php echo e($list->panjang); ?>m x <?php echo e($list->lebar); ?>m (<?php echo e($list->total); ?>m<sup>2</sup>)</p>
                </div>
                <div class="card-footer text-body-secondary">
                  <?php echo e($list->formatRupiah('tunai')); ?>,- <br>
                  
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek Laravel\mmgarden\resources\views/listkavling.blade.php ENDPATH**/ ?>
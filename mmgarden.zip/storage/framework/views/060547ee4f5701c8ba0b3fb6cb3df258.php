

<?php $__env->startSection('container'); ?>
    

<div class="jumbotron2 d-flex align-items-center">
    <div class="grid container text-center ">
        <div class="d-beranda mx-auto ">
            <h1><b class="border-bottom">PEMAKAMAN ISLAMI</b></h1>
            <h2>Berdasarkan <b>Syariat Islam</b> dan dikelola secara <b>Profesional</b></h2>
            <br>
            <h2>Berlokasi di <b>Kabupaten Bogor</b></h2>
            <a href="" class="btn btn-primary rounded-pill">CEK SEKARANG</a>
        </div>
    </div>
</div>

<div class="container text-center mt-3">
    <h1>Type Kavling Pemakaman Islami </h1>
    <h1><b>Madinah Memorial Garden</b></h1>
    <h3>Tersedia berbagai pilihan type kavpling yang dapat disesuaikan dengan kebutuan pengguna mulai dari kavling perorangan, pasangan atau keluarga.</h3>
    <h3>Berikut pilihan kavling yang tersedia di <strong>MMGarden</strong> :</h3>
    <div class="container text-center">
        <div class="row justify-content-evenly me-0 me-lg-5">
            <br>
          <div class="col-12 col-lg-5 text-bg-dark p-3 rounded">
            <h2><b>Berdasarkan Syariat Islam</b></h2>
            <h4 class="">Pemakaman Islam Madinah  Memori Garden Kab Bogor dikelola berdasarkan syariat Islam, mulai dari penanganan jenazah sebelum dimakamkan hingga perawatan dan penjagaan makam pasca pemakaman, seluruhnya mengikuti aturan Islam.</h4>
          </div>
          <div class="col-12 col-lg-5 text-bg-dark p-3 rounded mt-2 mt-lg-0">
            <h2><b>Dikelola Secara Profesional</b></h2>
            <h4 class="text-justify">Selain syar’i, Pemakaman Islam  Madinah Memori Garden Kab Bogor juga dikelola secara profesional sehingga menjadi salah satu taman pemakaman di Kab Bogor yang terbaik.</h4>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek Laravel\mmgarden\resources\views/typekavling.blade.php ENDPATH**/ ?>
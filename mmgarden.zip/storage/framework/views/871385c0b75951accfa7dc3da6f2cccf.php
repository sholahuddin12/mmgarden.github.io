

<?php $__env->startSection('container'); ?>
    

<div class="jumbotron d-flex align-items-center">
    <div class="grid container text-center ">
        <div class="d-tentang mx-auto ">
            <h1><b class="border-bottom">PEMAKAMAN ISLAMI</b></h1>
            <h2>Hadir untuk menjawab kekhawatiran umat Muslim mengenai area pemakaman yang sesuai dengan syariah Islam. Kami menfasilitasi khusus umat Muslim, mulai dari penyediaan lahan pemakaman hingga pelaksanaan prosesi pemakaman yang khidmat. Semua pelayanan kami dilakukan dengan profesion dan pastinya memenuhi syariah/madzhab Ahlussunnah Waljamaa’ah </h2>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek Laravel\mmgarden\resources\views/tentang.blade.php ENDPATH**/ ?>